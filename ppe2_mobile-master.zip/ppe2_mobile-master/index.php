<?php
if(session_status() == PHP_SESSION_NONE){
    session_start();
}

require 'model/functions.php';
?>

<?php

    if(!isset($_GET['action']))
        $_GET['action']="login";

    switch($_GET['action']) {
        case "login":
        require 'controller/login.php';
        break;

        case "vehicleList":
            //loggedOnly();
            require 'controller/vehicleList.php';
        break;

        case "createReservation":
            require 'controller/createReservation.php';
        break;

        case "reservation":
            require 'controller/reservation.php';
        break;

        case "endReservation":
            require 'controller/endReservation.php';
        break;

        case "logout":
            logout();
        break;
    }
?>


