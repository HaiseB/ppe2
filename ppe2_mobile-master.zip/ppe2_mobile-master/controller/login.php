<?php

require 'model/Carea.php';
/*reconnect_from_cookie();*/

if (!empty($_POST) && !empty($_POST['email']) && !empty($_POST['password'])){
    Area::login();
}

pages('login');