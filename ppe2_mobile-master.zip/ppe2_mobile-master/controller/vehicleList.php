<?php

require 'model/Creservation.php';
$reservations=Reservation::ongoingReservation();
dd($_SESSION);
//dd($reservations);

require 'model/Cvehicle.php';
$vehicles = Vehicle::getAvailableVehicles();

pages('vehicleList',['vehicles' => $vehicles]);