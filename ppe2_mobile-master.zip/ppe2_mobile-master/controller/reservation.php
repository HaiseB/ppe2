<?php

require 'model/Cvehicle.php';

$vehicle = Vehicle::findVehicle();

pages('reservation',['vehicle' => $vehicle]);