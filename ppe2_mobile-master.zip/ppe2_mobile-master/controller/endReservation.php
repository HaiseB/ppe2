<?php
require 'model/Cvehicle.php';
require 'model/Creservation.php';

$vehicle = Vehicle::findVehicle();
$now = date("H:i");

if (!empty($_POST) && !empty($_POST['kilometers']) && !empty($_POST['end'])){
    Reservation::endReservation();
    if (!isset($res)){
        unset($_SESSION['reservation']);
        header('location: index.php?action=vehicleList');
        exit();
    } else {
        $_SESSION['flash']['danger'] = "Les informations sont incorrectes, veuillez les entrez à nouveau.";
    }
}


pages('endReservation',['now' => $now,'vehicle' => $vehicle]);