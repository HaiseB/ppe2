<?php

require 'model/Creservation.php';
Reservation::createReservation();
header('location: index.php?action=reservation');
exit();