<div class="endReservation">
    <h3>Validation des informations</h3>
    <a href="index.php?action=logout" class="logoutButton"><i class="fas fa-power-off"></i></a>
    <div class="formulaire">
        <form action="" method="POST">
            <div class="form-group">
                <label for="">Nombre de kilomètres</label>
                <input type="text" name="kilometers" class="form-control" value="<?= $vehicle->kilometers ;?>" required/>
            </div>
            <div class="form-group">
                <label for="">Heure de fin</label>
                <input type="end" name="end" class="form-control" value="<?= $now;?>" required/>
            </div>
            <div class="form-group">
                <button class="btn btn-primary">Rendre le véhicule</button>
                <label>
            </div>
        </form>
    </div>
</div>