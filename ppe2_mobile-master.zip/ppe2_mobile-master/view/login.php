<div class="connexion">
    <h2>Connexion</h2>
    <div class="formulaire">
        <form action="" method="POST">
            <div class="form-group">
                <label for="">Nom</label>
                <input type="text" name="email" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="">Mot de passe</label>
                <input type="password" name="password" class="form-control" required/>
            </div>
            <div class="form-group">
                <button class="btn btn-primary">Connexion</button>
                <label>
            </div>
        </form>
    </div>
    <h6><a href="http://localhost/ppe2/">Se connecter à la version administration</a></h6>
</div>