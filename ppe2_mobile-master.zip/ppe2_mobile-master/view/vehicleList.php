<div class="vehicles">
    <h3>Cliquez pour réserver</h3>
    <a href="index.php?action=logout" class="logoutButton"><i class="fas fa-power-off"></i></a>
    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">Modèle</th>
                <th scope="col">Plaque</th>
                <th scope="col">Type</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($vehicles as $vehicle): ?>
                <tr>
                    <td><a href="index.php?action=createReservation&vehicleId=<?= $vehicle->id;?>"><?= $vehicle->brand;?> <?= $vehicle->model;?></a></th>
                    <td><a href="index.php?action=createReservation&vehicleId=<?= $vehicle->id;?>"><?= $vehicle->license_plate ;?></a></th>
                    <td><a href="index.php?action=createReservation&vehicleId=<?= $vehicle->id;?>"><?= $vehicle->type ;?></a></th>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>