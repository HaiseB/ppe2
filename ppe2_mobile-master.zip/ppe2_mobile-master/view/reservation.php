<h3>Information du véhicule</h3>
<a href="index.php?action=logout" class="logoutButton"><i class="fas fa-power-off"></i></a>
<div class="reservation">
    <div class="vehicleInfos">
        <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Type
                <span class="badge badge-primary badge-pill"><?= $vehicle->type;?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Plaque
                <span class="badge badge-primary badge-pill"><?= $vehicle->license_plate;?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Modèle
                <span class="badge badge-primary badge-pill"><?= $vehicle->model;?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Marque
                <span class="badge badge-primary badge-pill"><?= $vehicle->brand;?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Kilomètres
                <span class="badge badge-primary badge-pill"><?= $vehicle->kilometers;?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Autonomie
                <span class="badge badge-primary badge-pill"><?= $vehicle->autonomy;?></span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Carburant
                <span class="badge badge-primary badge-pill"><?= $vehicle->fuel;?></span></span>
            </li>
        </ul>
    </div>
    <div class="reservationInfos">
        <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Début de la réservation
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <?= substr($_SESSION['reservation']->start, 11, -8) ?>
            </li>
        </ul>
        <p class="lead">
            <a class="btn btn-primary btn-lg" href="index.php?action=endReservation" role="button">Terminer la reservation</a>
        </p>
    </div>
</div>