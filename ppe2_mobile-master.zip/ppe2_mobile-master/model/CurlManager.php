<?php

class CurlManager
{

    /**===================
     * - PHP curl function
     * ===================
     * @param string $url
     * @param string $method
     * @param array $data
     *
     * @return string|json array
     */
    public static function curlCall($url, $method = 'GET', $data = null)
    {
        $Authorization='Authorization:Bearer '.$_SESSION['token'];

        $ch = \curl_init();
        \curl_setopt($ch, \CURLOPT_URL, $url);
        \curl_setopt($ch, \CURLOPT_RETURNTRANSFER, true);
        \curl_setopt($ch, \CURLOPT_SSL_VERIFYPEER, false);
        \curl_setopt($ch, \CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
            $Authorization,
            'Charset: utf-8']);

        switch (\strtoupper($method)) {
            case "POST":
                \curl_setopt($ch, \CURLOPT_POST, 1);
                break;
            case "PUT":
                \curl_setopt($ch, \CURLOPT_PUT, 1);
                break;
            case "DELETE":
                \curl_setopt($ch, \CURLOPT_CUSTOMREQUEST, "DELETE");
                break;
            case "PATCH":
                \curl_setopt($ch, \CURLOPT_CUSTOMREQUEST, "PATCH");
                break;
        }

        if ($data) {
            \curl_setopt($ch, \CURLOPT_POSTFIELDS, $data);
        }

        $response = \curl_exec($ch);

        if (\curl_errno($ch)) {
            return \curl_error($ch);
        }

        \curl_close($ch);

        return $response;
    }
}
