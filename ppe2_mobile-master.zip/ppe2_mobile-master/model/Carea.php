<?php

require_once 'model/CurlManager.php';

class Area{
    public static function login(){
        $data = "email=".$_POST['email']."&password=".$_POST['password'];
        $req = CurlManager::curlCall('localhost:8080/api/users/login','POST',$data);
        $response = (json_decode($req));
        if (isset($response->error)){
            $_SESSION['flash']['danger'] = "Email ou mot de passe incorrect";
        } else {
            $_SESSION['token']=$response->token;
            /*if il y'a une réservation, envoyer dans la  route reservation + ajouter la réservation trouvéer dans le $_session*/
            header('location: index.php?action=vehicleList');
            exit();
        }
    }
}