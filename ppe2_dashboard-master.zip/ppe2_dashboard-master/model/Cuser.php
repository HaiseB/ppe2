<?php

require_once 'model/CurlManager.php';

class User{
    public static function allUsers(){
        $req = CurlManager::curlCall('localhost:8080/api/users/');
        $response = (json_decode($req));
        return $response;
    }

    public static function createUser(){
        $data = "email=".$_POST['email']."&name=".$_POST['name']."&first_name=".$_POST['first_name']."&password=".$_POST['password']."&bio=".$_POST['bio']."&role=".$_POST['role'];
        $req = CurlManager::curlCall('http://localhost:8080/api/users/register','POST',$data);
        $user = (json_decode($req));
        return $user;
    }

    public static function findUser(){
        $data = "id=".$_GET['idUser'];
        $req = CurlManager::curlCall('http://localhost:8080/api/users/search/','PATCH',$data);
        $user = (json_decode($req));
        return $user;
    }

    public static function updateUser(){
        $data = "id=".$_GET['idUser']."email=".$_POST['email']."&name=".$_POST['name']."&first_name=".$_POST['first_name']."&password=".$_POST['password']."&bio=".$_POST['bio']."&locked=1"."&role=".$_POST['role'];
        $req = CurlManager::curlCall('http://localhost:8080/api/users/update','POST',$data);
        $user = (json_decode($req));
        return $user;
    }
}


