<?php

require_once 'model/CurlManager.php';

class Vehicle{
    public static function getAllVehicles(){
        $data = CurlManager::curlCall('localhost:8080/api/vehicles');
        $vehicles = (json_decode($data));
        return $vehicles;
    }

    public static function getAvailableVehicles(){
        $data = CurlManager::curlCall('localhost:8080/api/vehicles/available');
        $vehicles = (json_decode($data));
        return $vehicles;
    }

    public static function findVehicle(){
        $data = "id=".$_GET['idVehicle'];
        $req = CurlManager::curlCall('localhost:8080/api/vehicles/search','PATCH',$data);
        $vehicle = (json_decode($req));
        return $vehicle;
    }

    public static function createVehicle(){
        $data = "type=".$_POST['type']."&license_plate=".$_POST['license_plate']."&kilometers=".$_POST['kilometers']."&autonomy=".$_POST['autonomy']."&fuel=".$_POST['fuel']."&model=".$_POST['model']."&brand=".$_POST['brand'];
        $req = CurlManager::curlCall('http://localhost:8080/api/vehicles/new','POST',$data);
        $vehicle = (json_decode($req));
        return $vehicle;
    }

    public static function updateVehicle(){
        $data = "type=".$_POST['type']."&license_plate=".$_POST['license_plate']."&model=".$_POST['model']."&brand=".$_POST['brand']."&kilometers=".$_POST['kilometers']."&autonomy=".$_POST['autonomy']."&fuel=".$_POST['fuel']."&locked=1";
        $req = CurlManager::curlCall('http://localhost:8080/api/vehicles/update','POST',$data);
        $vehicle = (json_decode($req));
        return $vehicle;
    }

}