<?php

require_once 'model/CurlManager.php';
require_once 'model/Cvehicle.php';

class Reservation{
    public static function createReservation(){
        $data = "vehicleId=".$_GET['vehicleId'];
        $req = CurlManager::curlCall('localhost:8080/api/reservations/new','POST',$data);
        $response = (json_decode($req));
        if (isset($response->error)){
            $_SESSION['flash']['danger'] = "La réservation à échouée, veuiller reessayer plus tard";
        } else {
            $_SESSION['reservation']=$response;
        }
    }

    public static function endReservation(){
        $vehicle = Vehicle::findVehicle();
        $now = date("H:i");
        $Authorization='Authorization:Bearer '.$_SESSION['token'];
        $data = "vehicleId=".$vehicle->id."&kilometers=".$vehicle->kilometers."&reservationId=".$_GET['reservationId']."&end=";

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_PORT => "8080",
        CURLOPT_URL => "http://localhost:8080/api/reservations/end",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Accept: */*",
            $Authorization,
            "Cache-Control: no-cache",
            "Connection: keep-alive",
            "Content-Type: application/x-www-form-urlencoded",
            "Host: localhost:8080",
            "Postman-Token: 924a63b6-b22d-4ddd-928f-247962efe261,5bccf5b5-342d-4da0-85a0-169dd7869067",
            "User-Agent: PostmanRuntime/7.13.0",
            "accept-encoding: gzip, deflate",
            "cache-control: no-cache",
            "content-length: 47"
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return $res = "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

    public static function ongoingReservation(){
        $data = CurlManager::curlCall('localhost:8080/api/reservations/ongoing');
        $reservations = (json_decode($data));
        return $reservations;
    }

    public static function completedReservation(){
        $data = CurlManager::curlCall('localhost:8080/api/reservations/completed?limit=5&order=id:DESC');
        $reservations = (json_decode($data));
        return $reservations;
    }

    public static function allReservations(){
        $data = CurlManager::curlCall('localhost:8080/api/reservations?order=id:DESC');
        $reservations = (json_decode($data));
        return $reservations;
    }
}

