<div class="jumbotron">
    <h1>Créer un utilisateur</h1>

    <form action="" method="POST" class="form">
        <div class="creationForm">
            <div>
                <div class="form-group row">
                    <label for="name">Nom</label>
                    <input type="text" required class="form-control" name="name">
                    <label for="first_name">Prénom</label>
                    <input type="text" required class="form-control" name="first_name">
                </div>
                <div class="form-group row">
                    <label for="bio">Emploi</label>
                    <input type="text" required class="form-control" name="bio">
                    <label for="role">Role</label>
                    <input type="text" required class="form-control" name="role">
                </div>
            </div>
            <div>
                <div class="form-group row">
                    <label for="email">Email</label>
                    <input type="int" required class="form-control" name="email">
                </div>
                <div class="form-group row">
                    <label for="password">Mot de passe</label>
                    <input type="password" required class="form-control" name="password">
                    <label for="confirmation_password">Confirmation du mot de passe</label>
                    <input type="password" required class="form-control" name="confirmation_password">
                </div>
                <div class="form-group row">
                    <button class="btn btn-primary">Créer l'utilisateur</button>
                </div>
            </div>
        </div>
    </form>

</div>