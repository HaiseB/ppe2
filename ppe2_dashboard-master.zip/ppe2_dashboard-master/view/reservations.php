<div class="jumbotron">
<h1>Liste des réservation</h1>


<table class="table table-hover">
    <thead>
        <tr>
        <th scope="col">N°</th>
        <th scope="col">Status</th>
        <th scope="col">Utilisateur</th>
        <th scope="col">Véhicule</th>
        <th scope="col">Début</th>
        <th scope="col">Fin</th>
        <th scope="col">Date Création</th>
        <th scope="col">Dernière Modification</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($reservations as $reservation): ?>
        <tr>
        <th scope="row"><?= $reservation->id ;?></th>
        <td><?= $reservation->status ;?></td>
        <td><?= $reservation->user->name ;?></td>
        <td><?= $reservation->vehicle->model ;?> - <?= $reservation->vehicle->license_plate ;?></td>
        <td>le <?= substr($reservation->start,0,10);?> à <?= substr($reservation->start,11,5);?></td>
        <td><?= substr($reservation->end,11,5) ;?></td>
        <td>le <?= substr($reservation->createdAt,0,10);?>  à <?= substr($reservation->createdAt,11,5);?> </td>
        <td>le <?= substr($reservation->updatedAt,0,10);?>  à <?= substr($reservation->updatedAt,11,5);?> </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>


</div>