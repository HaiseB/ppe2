<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="public/css/style.css">
        <link rel="stylesheet" href="public/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
        <link rel="shortcut icon" type="png" href="public/img/favicon.png"/>
        <title><?= isset($title) ? h($title) : 'Pommadan' ; ?></title>
    </head>
    <body>
    <?php if(isset($_SESSION['flash'])): ?>
        <?php foreach($_SESSION['flash'] as $type => $message): ?>
            <div class="alert alert-<?= $type; ?>">
                <?= $message; ?>
            </div>
        <?php endforeach; ?>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>
<div class="connexion">
    <h2>Connexion</h2>
    <div class="formulaire">
        <form action="" method="POST">
            <div class="form-group">
                <label for="">Nom</label>
                <input type="text" name="email" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="">Mot de passe</label>
                <input type="password" name="password" class="form-control" required/>
            </div>
            <div class="form-group">
                <button class="btn btn-primary">Connexion</button>
                <label>
            </div>
        </form>
    </div>
    <h6><a href="http://localhost/ppe2_mobile/">Se connecter à la version mobile</a></h6>
</div>
