<div class="jumbotron">
    <h1>Créer un véhicule</h1>

    <form action="" method="POST" class="form">
        <div class="creationForm">
            <div>
                <div class="form-group row">
                    <label for="type">Type</label>
                    <input type="text" required class="form-control" name="type">
                    <label for="license_plate">Plaque</label>
                    <input type="text" required class="form-control" name="license_plate">
                </div>
                <div class="form-group row">
                    <label for="model">Modèle</label>
                    <input type="text" required class="form-control" name="model">
                    <label for="brand">Marque</label>
                    <input type="text" required class="form-control" name="brand">
                </div>
            </div>
            <div>
                <div class="form-group row">
                    <label for="fuel">Carburant</label>
                    <input type="text" required class="form-control" name="fuel">
                </div>
                <div class="form-group row">
                    <label for="kilometers">Kilomètres</label>
                    <input type="int" required class="form-control" name="kilometers">
                    <label for="autonomy">Autonomie</label>
                    <input type="int" required class="form-control" name="autonomy">
                </div>
                <div class="form-group row">
                    <button class="btn btn-primary">Créer</button>
                </div>
            </div>
        </div>
    </form>

</div>