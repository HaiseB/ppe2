<div class="page">

<!-- Side Bar -->
<div class="sidebar">
    <p><i class="fas fa-users"></i> Utilisateurs
        <ul>
            <li><a href="index.php?action=addUser" ><i class="fas fa-plus-square"></i> Créer</a></li>
            <li><a href="index.php?action=user" ><i class="fas fa-pencil-alt"></i> Modifier</a></li>
        </ul>
    </p>
    <p><i class="fas fa-car"></i> Véhicules
        <ul>
            <li><a href="index.php?action=addVehicle" ><i class="fas fa-plus-square"></i> Créer</a></li>
            <li><a href="index.php?action=vehicle" ><i class="fas fa-pencil-alt"></i> Modifier</a></li>
        </ul>
    </p>
    <p><i class="fas fa-calendar"></i> Réservations
        <ul>
            <li><a href="index.php?action=reservations"><i class="fas fa-calendar-alt"></i> Afficher</a></li>
        </ul>
    </p>
</div>




<!-- Contenu de la page -->
<div class="content">

<!-- Ongoing reservations -->
<div class="ongoing">
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Reservations en cours</li>
</ol>


<div class="unusedVehicule ml-auto ml-md-0">
    <?php foreach($ongoingReservations as $ongoingReservation): ?>
        <div class="card text-white bg-primary mb-3" style="max-width: 20rem;">
            <div class="card-header"><?= $ongoingReservation->vehicle->brand;?> <?= $ongoingReservation->vehicle->model;?> - <?= $ongoingReservation->vehicle->license_plate;?></div>
            <div class="card-body">
                <p class="card-text">Utilisateur : <?= $ongoingReservation->user->name ;?></p>
                <p class="card-text">Heure de création : <?= substr($ongoingReservation->createdAt,11,5) ;?></p>
                <p class="card-text">Date : <?= substr($ongoingReservation->start,0,10) ;?></p>
                <p class="card-text">Heure de début : <?= substr($ongoingReservation->start,11,5) ;?></p>
                <button type="button" class="btn btn-secondary"><a href="index.php?action=endReservation&reservationId=<?= $ongoingReservation->id;?>&idVehicle=<?= $ongoingReservation->vehicleId;?>" class="card-link">Terminer la réservation</a></button>
            </div>
        </div>
    <?php endforeach; ?>
</div>
</div>

<!-- futures reservations - idée Graph d'occupation suivant heure?
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Reservations prévues</li>
</ol>
-->

<!-- occupancy rate
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Taux d'utilisation</li>
</ol>
<span class="badge badge-primary">Primary</span>
<span class="badge badge-secondary">Secondary</span>
<div class="progress">
    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 75%"></div>
</div>
-->

<!-- Unused vehicle -->
<div class="available">

<ol class="breadcrumb">
    <li class="breadcrumb-item active">Véhicules Disponibles</li>
</ol>


<table class="table table-hover">
    <thead>
        <tr>
        <th scope="col">Type</th>
        <th scope="col">Modèle</th>
        <th scope="col">Marque</th>
        <th scope="col">Plaque</th>
        <th scope="col">Nbr kilomètres</th>
        <th scope="col">Autonomie</th>
        <th scope="col">Carburant</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($availableVehicles as $availableVehicle): ?>
        <tr>
        <th scope="row"><?= $availableVehicle->type ;?></th>
        <td><?= $availableVehicle->model ;?></td>
        <td><?= $availableVehicle->brand ;?></td>
        <td><?= $availableVehicle->license_plate ;?></td>
        <td><?= $availableVehicle->kilometers ;?></td>
        <td><?= $availableVehicle->autonomy ;?></td>
        <td><?= $availableVehicle->fuel ;?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>


<!-- Tables -->
<div class="completed">
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Reservations terminées</li>
</ol>

<table class="table table-hover">
    <thead>
        <tr>
        <th scope="col">N°</th>
        <th scope="col">Status</th>
        <th scope="col">Utilisateur</th>
        <th scope="col">Véhicule</th>
        <th scope="col">Début</th>
        <th scope="col">Fin</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($reservations as $reservation): ?>
        <tr>
        <th scope="row"><?= $reservation->id ;?></th>
        <td><?= $reservation->status ;?></td>
        <td><?= $reservation->user->name ;?></td>
        <td><?= $reservation->vehicle->model ;?> - <?= $reservation->vehicle->license_plate ;?></td>
        <td>le <?= substr($reservation->start,0,10);?> à <?= substr($reservation->start,11,5);?></td>
        <td><?= substr($reservation->end,11,5) ;?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<a href="index.php?action=reservations"><< Afficher toutes les réservations >></a>
</div>


<footer class="footer">
</footer>

</div>
</div>