<div class="jumbotron">
    <h1>Modifier l'utilisateur : <?= h($user->name); ?> <?= h($user->first_name); ?></h1>

    <form action="" method="POST" class="form">
        <div class="creationForm">
            <div>
                <div class="form-group row">
                    <label for="name">Nom</label>
                    <input type="text" required class="form-control" name="name"
                        value="<?= isset($user->name) ? h($user->name) : ''; ?>">
                    <label for="first_name">Prénom</label>
                    <input type="text" required class="form-control" name="first_name"
                        value="<?= isset($user->first_name) ? h($user->first_name) : ''; ?>">
                </div>
                <div class="form-group row">
                    <label for="bio">Emploi</label>
                    <input type="text" required class="form-control" name="bio"
                        value="<?= isset($user->bio) ? h($user->bio) : ''; ?>">
                    <label for="role">Role</label>
                    <input type="text" required class="form-control" name="role"
                        value="<?= isset($user->role) ? h($user->role) : ''; ?>">
                </div>
            </div>
            <div>
                <div class="form-group row">
                    <label for="email">Email</label>
                    <input type="int" required class="form-control" name="email"
                        value="<?= isset($user->email) ? h($user->email) : ''; ?>">
                </div>
                <div class="form-group row">
                    <label for="password">Mot de passe</label>
                    <input type="password" required class="form-control" name="password"
                        value="<?= isset($user->password) ? h($user->password) : ''; ?>">
                    <label for="confirmation_password">Confirmation du mot de passe</label>
                    <input type="password" required class="form-control" name="confirmation_password"
                        value="<?= isset($user->password) ? h($user->password) : ''; ?>">
                </div>
                <div class="form-group row">
                    <button class="btn btn-primary">Valider la modification</button>
                </div>
            </div>
        </div>
    </form>

</div>