<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="public/css/bootstrap.min.css">
        <link rel="stylesheet" href="public/css/style.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
        <link rel="shortcut icon" type="png" href="public/img/favicon.png"/>
        <title><?= isset($title) ? h($title) : 'Pommadan' ; ?></title>
</head>

<body>
    <nav id="navbar" class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div>
        <a class="navbar-brand" href="index.php?action=dashboard">Pommadan</a>
        <button type="button" id="sidebarCollapse" class="btn btn-outline-secondary"><i class="fas fa-bars"></i></button>
        <button type="button" id="sidebarCollapse" class="btn btn-outline-secondary"><a href="index.php?action=dashboard"><i class="fas fa-home"></i></a></button>
    </div>
    <div id="div_horloge"></div>
    <div>
        <ul class="navbar-nav ml-auto ml-md-0">
            <li class="nav-item dropdown no-arrow mx-1">
                <button type="button" class="btn btn-outline-secondary"><i class="fas fa-envelope"></i></button>
            </li>
            <li class="nav-item dropdown no-arrow mx-1">
                <button type="button" class="btn btn-outline-secondary" ><a href="index.php?action=logout"><i class="fas fa-power-off"></i></a></button>
            </li>
        </ul>
    </div>
    </nav>

    <?php if(isset($_SESSION['flash'])): ?>
        <?php foreach($_SESSION['flash'] as $type => $message): ?>
            <div class="alert alert-<?= $type; ?>">
                <?= $message; ?>
            </div>
        <?php endforeach; ?>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>