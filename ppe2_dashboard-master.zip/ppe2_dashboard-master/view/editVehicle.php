<div class="jumbotron">
    <h1>Modification du véhicule : <?= $vehicle->brand; ?> <?= $vehicle->model; ?></h1>

    <form action="" method="POST" class="form">
        <div class="creationForm">
            <div>
                <div class="form-group row">
                    <label for="type">Type</label>
                    <input type="text" required class="form-control" name="type"
                    value="<?= isset($vehicle->type) ? h($vehicle->type) : ''; ?>">
                    <label for="license_plate">Plaque</label>
                    <input type="text" required class="form-control" name="license_plate"
                    value="<?= isset($vehicle->license_plate) ? h($vehicle->license_plate) : ''; ?>">
                </div>
                <div class="form-group row">
                    <label for="model">Modèle</label>
                    <input type="text" required class="form-control" name="model"
                    value="<?= isset($vehicle->model) ? h($vehicle->model) : ''; ?>">
                    <label for="brand">Marque</label>
                    <input type="text" required class="form-control" name="brand"
                    value="<?= isset($vehicle->brand) ? h($vehicle->brand) : ''; ?>">
                </div>
            </div>
            <div>
                <div class="form-group row">
                    <label for="fuel">Carburant</label>
                    <input type="text" required class="form-control" name="fuel"
                    value="<?= isset($vehicle->fuel) ? h($vehicle->fuel) : ''; ?>">
                </div>
                <div class="form-group row">
                    <label for="kilometers">Kilomètres</label>
                    <input type="int" required class="form-control" name="kilometers"
                    value="<?= isset($vehicle->kilometers) ? h($vehicle->kilometers) : ''; ?>">
                    <label for="autonomy">Autonomie</label>
                    <input type="int" required class="form-control" name="autonomy"
                    value="<?= isset($vehicle->autonomy) ? h($vehicle->autonomy) : ''; ?>">
                </div>
                <div class="form-group row">
                    <button class="btn btn-primary">Confirmer les modifications</button>
                </div>
            </div>
        </div>
    </form>

</div>