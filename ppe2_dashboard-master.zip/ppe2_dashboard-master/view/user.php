<div class="jumbotron">
<h1>Liste des utilisateurs</h1>


<table class="table table-hover">
    <thead>
        <tr>
        <th scope="col">Nom</th>
        <th scope="col">Prénom</th>
        <th scope="col">Poste</th>
        <th scope="col">Email</th>
        <th scope="col">Rôle</th>
        <th scope="col">Modifier</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($Users as $User): ?>
        <tr>
        <th scope="row"><?= $User->name ;?></th>
        <td><?= $User->first_name ;?></td>
        <td><?= $User->bio ;?></td>
        <td><?= $User->email ;?></td>
        <td><?= $User->role ;?></td>
        <td><a href="index.php?action=editUser&idUser=<?= $User->id ;?>"><i class="fas fa-pencil-alt"></i></a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>


</div>