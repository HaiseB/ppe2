<div class="jumbotron">
<h1>Liste des véhicules</h1>


<table class="table table-hover">
    <thead>
        <tr>
        <th scope="col">Type</th>
        <th scope="col">Modèle</th>
        <th scope="col">Marque</th>
        <th scope="col">Plaque</th>
        <th scope="col">Nbr kilomètres</th>
        <th scope="col">Autonomie (en km)</th>
        <th scope="col">Disponible</th>
        <th scope="col">Carburant</th>
        <th scope="col">Modifier</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($Vehicles as $Vehicle): ?>
        <tr>
        <th scope="row"><?= $Vehicle->type ;?></th>
        <td><?= $Vehicle->model ;?></td>
        <td><?= $Vehicle->brand ;?></td>
        <td><?= $Vehicle->license_plate ;?></td>
        <td><?= $Vehicle->kilometers ;?></td>
        <td><?= $Vehicle->autonomy ;?></td>
        <td><?php if($Vehicle->locked == 1){ echo 'Non';} else { echo 'Oui';} ;?></td>
        <td><?= $Vehicle->fuel ;?></td>
        <td><a href="index.php?action=editVehicle&idVehicle=<?= $Vehicle->id ;?>"><i class="fas fa-pencil-alt"></i></a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>


</div>