<?php

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    require_once 'model/Cuser.php';
    $user=User::createUser();
    if (isset($user->error)){
        $_SESSION['flash']['danger'] = $user->error;
    } else {
        $_SESSION['flash']['success'] = "L'utilisateur à bien été créé";
    header('location: index.php?action=dashboard');
    exit();
    }
}

pages('addUser',['title' => "Créer un nouvel utilisateur"]);