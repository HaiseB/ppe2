<?php

require 'model/Cvehicle.php';

$Vehicles = Vehicle::getAllVehicles();

pages('vehicle',['title' => "Liste des véhicules",'Vehicles' => $Vehicles ]);