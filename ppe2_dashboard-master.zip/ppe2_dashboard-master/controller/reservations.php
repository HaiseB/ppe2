<?php

require 'model/Creservation.php';

$reservations = Reservation::allReservations();

pages('reservations',['title' => 'Toutes les réservations','reservations'=> $reservations]);