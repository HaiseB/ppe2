<?php
require 'model/Cvehicle.php';
require 'model/Creservation.php';

dd($vehicle);
Reservation::endReservation();

if (!isset($res)){
    $_SESSION['flash']['success'] = "La réservation à bien été terminée";
    header('location: index.php?action=dashboard');
    exit();
} else {
    $_SESSION['flash']['danger'] = "Le site à rencontré une erreur et n'a pas reussis à terminer la réservation.";
    header('location: index.php?action=dashboard');
    exit();
}