<?php

require_once 'model/Cuser.php';
$user=User::findUser();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $response=User::updateUser();
    if (isset($response->error)){
        $_SESSION['flash']['danger'] = $response->error;
    } else {
        $_SESSION['flash']['success'] = "L'utilisateur à bien été modifié";
        header('location: index.php?action=dashboard');
        exit();
    }
}

pages('editUser',['title' => "Modifier un utilisateur",'user' => $user]);