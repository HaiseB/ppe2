<?php

require 'model/Cvehicle.php';
require 'model/Creservation.php';

$ongoingReservations = Reservation::ongoingReservation();
$reservations = Reservation::completedReservation();
$availableVehicles = Vehicle::getAvailableVehicles();

//$completedReservations = Reservation::completedReservation();

pages('dashboard',['title' => 'Tableau de bord','ongoingReservations'=> $ongoingReservations,'reservations'=> $reservations,'availableVehicles'=> $availableVehicles]);