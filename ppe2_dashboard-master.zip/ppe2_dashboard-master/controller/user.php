<?php

require 'model/Cuser.php';

$Users = User::allUsers();

pages('user',['title' => "Liste des utilisateurs",'Users' => $Users ]);