<?php

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    require_once 'model/Cvehicle.php';
    $vehicle=Vehicle::createVehicle();
    if (isset($vehicle->error)){
        $_SESSION['flash']['danger'] = $vehicle->error;
    } else {
        $_SESSION['flash']['success'] = "Le véhicule à bien été créé";
        header('location: index.php?action=dashboard');
        exit();
    }
}

pages('addVehicle',['title' => "Créer un nouveau véhicule"]);