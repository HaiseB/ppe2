<?php

require_once 'model/Cvehicle.php';
$vehicle=Vehicle::findVehicle();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $response=Vehicle::updateVehicle();
    if (isset($response->error)){
        $_SESSION['flash']['danger'] = $response->error;
    } else {
        $_SESSION['flash']['success'] = "Le véhicule à bien été modifié";
        header('location: index.php?action=dashboard');
        exit();
    }
}

pages('editVehicle',['title' => "Modifier un véhicule",'vehicle' => $vehicle]);