<?php
if(session_status() == PHP_SESSION_NONE){
    session_start();
}
require 'model/functions.php';

    if(!isset($_GET['action']))
        $_GET['action']="login";

    switch($_GET['action']) {
        case "login":
        require 'controller/login.php';
        break;

        case "dashboard":
            require 'controller/dashboard.php';
        break;

        case "endReservation":
            require 'controller/endReservation.php';
        break;

        case "reservations":
            require 'controller/reservations.php';
        break;

        case "endReservation":
            require 'controller/endReservation.php';
        break;

        case "addUser":
        require 'controller/addUser.php';
        break;

        case "user":
            require 'controller/user.php';
        break;

        case "editUser":
            require 'controller/editUser.php';
        break;

        case "addVehicle":
        require 'controller/addVehicle.php';
        break;

        case "vehicle":
            require 'controller/vehicle.php';
        break;

        case "editVehicle":
            require 'controller/editVehicle.php';
        break;

        case "logout":
            logout();
        break;
    };
?>
